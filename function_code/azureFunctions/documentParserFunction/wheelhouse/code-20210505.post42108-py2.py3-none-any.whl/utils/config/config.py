
config = {}
config['parse'] = True
config['parseDocNames'] = []  